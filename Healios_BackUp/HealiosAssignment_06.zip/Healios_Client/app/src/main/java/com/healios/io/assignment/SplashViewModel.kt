package com.healios.io.assignment

import android.app.Application
import com.healios.io.assignment.app_base_component.BaseViewModel


class SplashViewModel(application: Application): BaseViewModel(application) {


}