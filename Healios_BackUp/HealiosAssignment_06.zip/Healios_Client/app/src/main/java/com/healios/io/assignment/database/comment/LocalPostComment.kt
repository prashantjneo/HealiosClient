package com.healios.io.assignment.database.comment

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "local_post_comment")
data class LocalPostComment(
    @PrimaryKey(autoGenerate = true)
    val cID: Long = 0L,

    @ColumnInfo(name = "PostID")
    val PostID: Int?,

    @ColumnInfo(name = "Id")
    val Id: Int?,

    @ColumnInfo(name = "Name")
    val Name: String?,

    @ColumnInfo(name = "Email")
    val Email: String?,

    @ColumnInfo(name = "Body")
    val Body: String?
)
