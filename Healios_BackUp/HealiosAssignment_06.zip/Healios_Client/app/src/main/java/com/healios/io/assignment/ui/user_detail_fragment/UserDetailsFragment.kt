package com.healios.io.assignment.ui.user_detail_fragment

import android.os.Bundle
import androidx.lifecycle.Observer
import com.healios.io.assignment.R
import com.healios.io.assignment.app_base_component.BaseFragment
import com.healios.io.assignment.databinding.FragmentUserDetailsBinding
import com.healios.io.assignment.utils.showMessage


class UserDetailsFragment : BaseFragment<FragmentUserDetailsBinding, UserDetailViewModel>() {

    companion object {
        fun newInstance(userId: Int, IDS: Int, title: String, body: String) = UserDetailsFragment()
            .apply {
                arguments = Bundle().apply {
                    putInt(USERID, userId)
                    putInt(IDES, IDS)
                    putString(TITLE, title)
                    putString(BODY, body)
                }
            }

        private const val USERID = "userid"
        private const val IDES = "ids"
        private const val TITLE = "title"
        private const val BODY = "body"
    }

    override fun getLayoutId() = R.layout.fragment_user_details

    override fun getViewModel() = UserDetailViewModel::class.java

    override fun onBinding() {

        mBinding.run {
            lifecycleOwner = viewLifecycleOwner
            viewModel = mViewModel

        }
        getRemoteAllUserDetails()
        getRemoteAllPostComment()
        getLocalUserDetails()
        setObservers()
    }

    private fun getLocalUserDetails() {
        mViewModel.getSelectedUserFromLocal(arguments?.getInt(USERID)!!)

    }

    private fun getRemoteAllUserDetails() {
        mViewModel.callRemoteUserDetails()
    }

    private fun getRemoteAllPostComment() {
        mViewModel.callRemotePostComment()
    }

    private fun setObservers() {
        mViewModel.getLocalUserDetails().observe(viewLifecycleOwner, Observer {

        })

        mViewModel.getLocalPostComment().observe(viewLifecycleOwner, Observer {
        })

        mViewModel.getLocalUserDetails.observe(viewLifecycleOwner, Observer {

            showMessage(it.name)
        })
    }
}