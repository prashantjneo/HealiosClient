package com.healios.io.assignment.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "local_post_comment_table")
data class LocalPostComment(
    @PrimaryKey(autoGenerate = true)
    val cID: Long = 0L,

    @ColumnInfo(name = "PostID")
    val PostID: Int?,

    @ColumnInfo(name = "Id")
    val Id: Int?,

    @ColumnInfo(name = "Name")
    val Name: String?,

    @ColumnInfo(name = "Email")
    val Email: String?,

    @ColumnInfo(name = "Body")
    val Body: String?
    )
