package com.healios.io.assignment.database

import androidx.room.Dao

@Dao
interface LocalPostCommentDao {
}