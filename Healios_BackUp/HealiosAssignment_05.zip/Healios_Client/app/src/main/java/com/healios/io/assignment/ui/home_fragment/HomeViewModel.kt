package com.healios.io.assignment.ui.home_fragment

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.healios.io.assignment.app_base_component.BaseViewModel
import com.healios.io.assignment.database.LocalPost
import com.healios.io.assignment.network.repositories.Home
import kotlinx.coroutines.launch

class HomeViewModel(application: Application) : BaseViewModel(application) {

    fun callRemotePosts() {

        setDialogVisibility(true)

        coroutineScope.launch {
            Home.getRemoteFunds()
        }
    }

    fun getLocalPosts(): LiveData<List<LocalPost>> {

        return Home.getPostsFromDatabase()
    }
}