package com.healios.io.assignment.network.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

data class RemotePostComments(
    @SerializedName("PostID") @Expose val PostID: Int?,
    @SerializedName("Id") @Expose val Id: Int?,
    @SerializedName("Name") @Expose val Name: String?,
    @SerializedName("Email") @Expose val Email: String?,
    @SerializedName("Body") @Expose val Body: String?,
)
