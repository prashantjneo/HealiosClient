package com.healios.io.assignment.ui.home_fragment

import android.widget.Toast
import androidx.lifecycle.Observer
import com.healios.io.assignment.R
import com.healios.io.assignment.app_base_component.BaseFragment
import com.healios.io.assignment.databinding.FragmentHomeBinding


class HomeFragment : BaseFragment<FragmentHomeBinding, HomeViewModel>() {

    companion object {
        fun newInstance() = HomeFragment()
    }

    override fun getLayoutId(): Int {
        return R.layout.fragment_home
    }

    override fun getViewModel(): Class<HomeViewModel> {
        return HomeViewModel::class.java
    }

    override fun onBinding() {

        mBinding.run {
            lifecycleOwner = viewLifecycleOwner
            viewModel = mViewModel
        }
        getPosts()
        observePosts()
    }

    private fun getPosts() {

        mViewModel.callRemotePosts()
    }

    private fun observePosts() {
        mViewModel.getLocalPosts().observe(viewLifecycleOwner, Observer {
            Toast.makeText(context, "" + it?.get(0)?.Title, Toast.LENGTH_SHORT).show()

        })
    }

}