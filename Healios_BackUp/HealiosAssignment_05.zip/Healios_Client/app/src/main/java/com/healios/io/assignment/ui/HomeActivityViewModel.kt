package com.healios.io.assignment.ui

import android.app.Application
import com.healios.io.assignment.app_base_component.BaseViewModel

class HomeActivityViewModel(application: Application):BaseViewModel(application) {
}